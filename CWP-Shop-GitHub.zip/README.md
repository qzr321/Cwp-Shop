# CWP Shop — GitHub Pages

1. Utwórz publiczne repozytorium na GitHub, np. `cwp-shop`.
2. Wrzuć do niego `index.html`, `style.css` oraz `hero.png`.
3. Wejdź w Settings → Pages.
4. W `Build and deployment` wybierz `Deploy from a branch`.
5. Branch: `main`, folder: `/ (root)`.
6. Zapisz. Po chwili GitHub poda adres strony.

W plikach znajdziesz dane przykładowe — podmień ceny, Discord i e-mail na swoje.
