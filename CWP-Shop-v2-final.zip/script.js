const menu=document.querySelector('.menu'),nav=document.querySelector('nav');if(menu)menu.addEventListener('click',()=>nav.classList.toggle('show'));
